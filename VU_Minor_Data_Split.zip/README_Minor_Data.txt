VU MINOR-COURSE DATA — SPLIT FILES

This package separates each worksheet in the original minor-course workbook
into its own Excel file. The original sheet values and row/column positions
are retained. No course details, eligibility rules, batch labels or codes have
been inferred or corrected.

IMPORTANT DATA RULES FOR THE ADVISOR
1. Do not assume that every listed minor is available to every VU programme.
2. Do not assume that this workbook is only for B.Tech merely because of its
   original filename. Confirm programme eligibility from the source.
3. Preserve batch/year labels exactly as shown in each sheet.
4. Keep course code, title, semester, credits and prerequisite together as
   one course record wherever the layout permits.
5. If a sheet does not specify a programme, batch or course code, report that
   the source does not specify it. Do not invent missing information.
6. When the user asks which minors are available to a programme, answer only
   from confirmed programme-specific evidence. Otherwise ask for clarification
   or explain that the available document does not establish eligibility.

The split is for file organisation. The application still needs a parser that
extracts structured course records and attaches source filename/sheet metadata.
