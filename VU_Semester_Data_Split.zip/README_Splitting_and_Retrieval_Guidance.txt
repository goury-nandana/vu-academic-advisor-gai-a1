VU ACADEMIC ADVISOR — SEMESTER DATA SPLIT

This ZIP contains one Excel file for each original worksheet (10 files total).
Semester spreads and programme structures are separated by batch.

WHY THIS IS THE RECOMMENDED ORGANISATION
- Each batch has a clearly labelled semester-spread source.
- Programme structures are kept separate from semester offerings.
- Retrieval can filter by batch and document type before searching course details.
- Different course codes across batches are less likely to be mixed accidentally.

FILES
01–05: Semester spreads for 2022, 2023, 2024, 2025 and 2026 DS.
06–10: Programme structures for 2022, 2023, 2024, 2025 and 2026 DS.

RETRIEVAL METADATA TO ATTACH IN THE APP
- document_type: semester_spread or programme_structure
- programme: exact programme stated in the source
- batch: 2022 / 2023 / 2024 / 2025 / 2026
- source_sheet: original worksheet name
- semester: where applicable

COURSE-CODE QUESTION LOGIC
1. Identify the student's programme and batch.
2. Search the matching batch-specific source first.
3. Compare other batches only for historical/change questions or when needed.
4. State which batch each code applies to and cite the matching source.
5. If the batch is unknown and codes differ, ask the student or explain the alternatives.

IMPORTANT
Splitting files is only an organisation step. The Excel parser must still read the
multi-column semester layout correctly and preserve course code, title, credits,
basket, semester and programme relationships. Verify extracted records against
the original workbook before deploying. No academic content has intentionally
been rewritten or corrected.

Note: cell values, row/column positions, merged ranges and basic dimensions are
preserved. Original Excel styling/theme may not be identical in the split files.
